import pandas as pd


def validate_required_columns(df: pd.DataFrame, required_columns: list[str]) -> None:
    missing = [col for col in required_columns if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")


def validate_no_nulls(df: pd.DataFrame, columns: list[str]) -> None:
    null_columns = [col for col in columns if df[col].isnull().any()]
    if null_columns:
        raise ValueError(f"Null values found in columns: {null_columns}")


def validate_positive_values(df: pd.DataFrame, column: str) -> None:
    if (df[column] <= 0).any():
        raise ValueError(f"Column {column} contains zero or negative values")


def validate_unique_key(df: pd.DataFrame, key_column: str) -> None:
    if df[key_column].duplicated().any():
        raise ValueError(f"Duplicate values found in key column: {key_column}")
