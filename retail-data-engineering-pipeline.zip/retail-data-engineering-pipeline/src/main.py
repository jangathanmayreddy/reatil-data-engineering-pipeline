from config import RAW_DATA_DIR, DB_PATH, BASE_DIR
from extract import read_csv_file
from transform import clean_customers, clean_products, clean_orders
from load import load_dataframe, execute_sql_file
from data_quality import (
    validate_required_columns,
    validate_no_nulls,
    validate_positive_values,
    validate_unique_key,
)


def run_pipeline() -> None:
    customers = read_csv_file(RAW_DATA_DIR / "customers.csv")
    products = read_csv_file(RAW_DATA_DIR / "products.csv")
    orders = read_csv_file(RAW_DATA_DIR / "orders.csv")

    validate_required_columns(customers, ["customer_id", "customer_name", "email", "region"])
    validate_required_columns(products, ["product_id", "product_name", "category"])
    validate_required_columns(orders, ["order_id", "customer_id", "product_id", "order_date", "quantity", "unit_price"])

    validate_unique_key(customers, "customer_id")
    validate_unique_key(products, "product_id")
    validate_unique_key(orders, "order_id")

    validate_no_nulls(orders, ["order_id", "customer_id", "product_id", "order_date"])
    validate_positive_values(orders, "quantity")
    validate_positive_values(orders, "unit_price")

    customers_clean = clean_customers(customers)
    products_clean = clean_products(products)
    orders_clean = clean_orders(orders)

    load_dataframe(customers_clean, "stg_customers", DB_PATH)
    load_dataframe(products_clean, "stg_products", DB_PATH)
    load_dataframe(orders_clean, "stg_orders", DB_PATH)

    for sql_file in ["dim_customers.sql", "dim_products.sql", "fact_sales.sql"]:
        execute_sql_file(BASE_DIR / "sql" / "models" / sql_file, DB_PATH)

    print("Retail sales pipeline completed successfully.")


if __name__ == "__main__":
    run_pipeline()
