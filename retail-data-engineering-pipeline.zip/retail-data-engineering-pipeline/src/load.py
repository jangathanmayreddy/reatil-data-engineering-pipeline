import sqlite3
import pandas as pd
from pathlib import Path


def load_dataframe(df: pd.DataFrame, table_name: str, db_path: Path) -> None:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(db_path) as conn:
        df.to_sql(table_name, conn, if_exists="replace", index=False)


def execute_sql_file(sql_path: Path, db_path: Path) -> None:
    with sqlite3.connect(db_path) as conn:
        sql = sql_path.read_text()
        conn.executescript(sql)
