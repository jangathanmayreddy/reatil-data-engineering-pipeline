import pandas as pd


def clean_customers(customers: pd.DataFrame) -> pd.DataFrame:
    customers = customers.copy()
    customers["customer_name"] = customers["customer_name"].str.strip().str.title()
    customers["email"] = customers["email"].str.strip().str.lower()
    customers["region"] = customers["region"].str.strip().str.title()
    return customers


def clean_products(products: pd.DataFrame) -> pd.DataFrame:
    products = products.copy()
    products["product_name"] = products["product_name"].str.strip().str.title()
    products["category"] = products["category"].str.strip().str.title()
    return products


def clean_orders(orders: pd.DataFrame) -> pd.DataFrame:
    orders = orders.copy()
    orders["order_date"] = pd.to_datetime(orders["order_date"])
    orders["sales_amount"] = orders["quantity"] * orders["unit_price"]
    return orders
