import pandas as pd
import pytest
from src.data_quality import validate_required_columns, validate_positive_values, validate_unique_key


def test_validate_required_columns_passes():
    df = pd.DataFrame({"id": [1], "name": ["test"]})
    validate_required_columns(df, ["id", "name"])


def test_validate_required_columns_fails():
    df = pd.DataFrame({"id": [1]})
    with pytest.raises(ValueError):
        validate_required_columns(df, ["id", "name"])


def test_validate_positive_values_fails():
    df = pd.DataFrame({"quantity": [1, -2, 3]})
    with pytest.raises(ValueError):
        validate_positive_values(df, "quantity")


def test_validate_unique_key_fails():
    df = pd.DataFrame({"order_id": [101, 101, 102]})
    with pytest.raises(ValueError):
        validate_unique_key(df, "order_id")
