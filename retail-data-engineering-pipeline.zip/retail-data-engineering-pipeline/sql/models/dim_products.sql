DROP TABLE IF EXISTS dim_products;

CREATE TABLE dim_products AS
SELECT
    product_id,
    product_name,
    category
FROM stg_products;
