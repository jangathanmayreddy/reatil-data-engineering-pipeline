DROP TABLE IF EXISTS fact_sales;

CREATE TABLE fact_sales AS
SELECT
    o.order_id,
    o.order_date,
    o.customer_id,
    o.product_id,
    o.quantity,
    o.unit_price,
    o.sales_amount,
    c.region,
    p.category
FROM stg_orders o
LEFT JOIN dim_customers c ON o.customer_id = c.customer_id
LEFT JOIN dim_products p ON o.product_id = p.product_id;
